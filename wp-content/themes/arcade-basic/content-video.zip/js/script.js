jQuery(document).ready(function($){
/*
var images=[];
images[1]='http://theheavenhomes.com/wp-content/uploads/2015/01/Luxury-log-home-interiors-and-decorating-ideas-1.jpg';
images[2]='http://theheavenhomes.com/wp-content/uploads/2015/01/homes-and-interior-scotland-13702136.jpg';
setTimeout(function(){$(".header-img").attr("src",images[1])}, 6000);
setTimeout(function(){$(".header-img").attr("src",images[2])}, 12000);
*/
});